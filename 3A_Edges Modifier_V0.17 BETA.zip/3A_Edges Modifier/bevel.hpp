#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <map>
#include <set>
#include <vector>
#include <utility>
namespace bevel {
struct V { double x=0,y=0,z=0;
 V operator+(V b)const{return {x+b.x,y+b.y,z+b.z};}
 V operator-(V b)const{return {x-b.x,y-b.y,z-b.z};}
 V operator*(double s)const{return {x*s,y*s,z*s};}
};
inline double dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline double length(V a){return std::sqrt(dot(a,a));}
inline V unit(V a){double l=length(a);return l>1e-12?a*(1/l):V{};}
using Loop=std::vector<int>;
using Key=std::pair<int,int>;
inline Key key(int a,int b){return std::minmax(a,b);}
struct Face{Loop v;int source;};
struct Mesh{std::vector<V> p;std::vector<Face> f;};
// Identify emitted geometry independently of transient host IDs and scan order.
using FaceKey=std::vector<std::array<float,3>>;
using FaceSet=std::map<FaceKey,unsigned>;
inline FaceSet faceSet(const Mesh &mesh){
 FaceSet result;
 for(const auto &face:mesh.f){
  FaceKey vertices;
  for(int index:face.v){const V p=mesh.p[index];vertices.push_back({float(p.x),float(p.y),float(p.z)});}
  std::sort(vertices.begin(),vertices.end());
  ++result[vertices];
 }
 return result;
}
inline bool containsOutput(const Mesh &incoming,const FaceSet &output){
 if(output.empty())return false;
 const auto current=faceSet(incoming);
 for(const auto &entry:output){
  auto i=current.find(entry.first);
  if(i==current.end()||i->second<entry.second)return false;
 }
 return true;
}
struct Half{int f,i,a,b;};
inline Mesh run(const Mesh &m,double radius,int segments,const std::vector<double>&weight,
                bool manual,const std::set<Key>& selected,double angle,bool repairLoops=false){
 Mesh out=m;
 std::map<Key,std::vector<Half>> edges;
 std::vector<V> normals;
 std::map<Key,double> widths;
 std::vector<Loop> corners;
 for(int f=0;f<(int)m.f.size();++f){
  const auto &v=m.f[f].v; V n{};
  for(int i=0;i<(int)v.size();++i){int a=v[i],b=v[(i+1)%v.size()];
   n=n+cross(m.p[a]-m.p[v[0]],m.p[b]-m.p[v[0]]);
   edges[key(a,b)].push_back({f,i,a,b});}
  normals.push_back(unit(n));corners.push_back(v);
 }
 std::vector<bool> interior(m.p.size(),false);
 for(auto &[k,h]:edges){
  if(h.size()!=2||h[0].a!=h[1].b||h[0].b!=h[1].a)continue;
  if(manual&&!selected.count({h[0].f+1,h[0].i+1})&&!selected.count({h[1].f+1,h[1].i+1}))continue;
  double cosine=std::clamp(dot(normals[h[0].f],normals[h[1].f]),-1.,1.);
  double theta=std::acos(cosine);
  if(theta<=1e-5||theta<angle||cosine<-.99999)continue;
  if(dot(cross(normals[h[0].f],normals[h[1].f]),m.p[h[0].b]-m.p[h[0].a])<0)
   interior[k.first]=interior[k.second]=true;
  widths[k]=radius*std::tan(theta*.5);
 }
 // A planar mitre between two rim faces needs its own transverse rows.
 // Test the original sharp edges before enabling any planar guides.
 std::set<Key> guideEdges;
 if(repairLoops && segments>1){
  std::vector<Key> guides;
  for(const auto &[k,h]:edges){
   if(h.size()!=2 || h[0].a!=h[1].b || h[0].b!=h[1].a)continue;
   if(dot(normals[h[0].f],normals[h[1].f])<1.-1e-8)continue;
   bool bendsAtEnd=false;
   for(int end:{k.first,k.second}){
    if(!interior[end])continue;
    int adjacent[2];
    for(int j=0;j<2;++j){
     const Half &side=h[j];const auto &loop=m.f[side.f].v;
     adjacent[j]=side.a==end?loop[(side.i+loop.size()-1)%loop.size()]:loop[(side.i+2)%loop.size()];
    }
    if(!widths.count(key(end,adjacent[0]))||!widths.count(key(end,adjacent[1])))continue;
    V u=unit(m.p[adjacent[0]]-m.p[end]),v=unit(m.p[adjacent[1]]-m.p[end]);
    if(length(cross(u,v))>1e-5)bendsAtEnd=true;
   }
   if(bendsAtEnd)guides.push_back(k);
  }
  for(Key guide:guides){widths[guide]=radius;guideEdges.insert(guide);}
 }
 auto localWidth=[&](Key edge,int point){
  return !interior[point] && guideEdges.count(edge)?0.:widths[edge];
 };
 // Corner offsets solve the two inset-line constraints in the face plane.
 std::vector<std::vector<int>> at(m.p.size());
 auto add=[&](int origin,V pos){
  if(length(pos-m.p[origin])<1e-10)return origin;
  for(int idx:at[origin])if(length(out.p[idx]-pos)<1e-9)return idx;
  int idx=out.p.size();out.p.push_back(pos);at[origin].push_back(idx);return idx;
 };
 std::vector<std::vector<V>> offsets(m.f.size());
 double scale=1;
 bool contact=false;
 for(int f=0;f<(int)m.f.size();++f){
  const Loop &v=m.f[f].v;int n=v.size();
  for(int i=0;i<n;++i){
   int a=v[(i+n-1)%n],b=v[i],c=v[(i+1)%n];
   V prev=m.p[b]-m.p[a],next=m.p[c]-m.p[b];
   V u=cross(normals[f],unit(prev)),w=cross(normals[f],unit(next));
   double co=dot(u,w),den=1-co*co;
   double d=localWidth(key(a,b),b)*weight[b],e=localWidth(key(b,c),b)*weight[b];
   V offset=den>1e-10?(u*(d-co*e)+w*(e-co*d))*(1/den):u*std::max(d,e);
   offsets[f].push_back(offset);
  }
 }
 // Coplanar pieces of a split face share one inset corner. Propagate the
 // two boundary constraints across their common, unselected internal seams.
 std::vector<std::vector<Key>> fans(m.p.size());
 for(int f=0;f<(int)m.f.size();++f)
  for(int i=0;i<(int)m.f[f].v.size();++i)fans[m.f[f].v[i]].push_back({f,i});
 for(size_t point=0;point<fans.size();++point){
  std::set<Key> pending(fans[point].begin(),fans[point].end());
  while(!pending.empty()){
   std::vector<Key> group{*pending.begin()};pending.erase(pending.begin());
   std::vector<std::pair<V,double>> constraints;
   for(size_t k=0;k<group.size();++k){
    auto [f,i]=group[k];const Loop &loop=m.f[f].v;int n=loop.size();
    for(int direction:{-1,1}){
     int other=loop[(i+n+direction)%n];Key edge=key(point,other);
     if(localWidth(edge,point)>0){
      V tangent=unit((m.p[other]-m.p[point])*direction);
      constraints.push_back({cross(normals[f],tangent),widths[edge]*weight[point]});
     }else if(edges[edge].size()==2){
      for(auto h:edges[edge])if(h.f!=f && dot(normals[f],normals[h.f])>1.-1e-10){
       int corner=h.a==(int)point?h.i:(h.i+1)%m.f[h.f].v.size();
       if(pending.erase({h.f,corner}))group.push_back({h.f,corner});
      }
     }
    }
   }
   if(group.size()<2 || constraints.size()!=2)continue;
   auto [u,d]=constraints[0];auto [w,e]=constraints[1];
   double co=dot(u,w),den=1-co*co;
   if(den<1e-10)continue;
   V inset=(u*(d-co*e)+w*(e-co*d))*(1/den);
   for(auto [f,i]:group)offsets[f][i]=inset;
  }
 }
 for(size_t f=0;f<m.f.size();++f){
  const Loop &v=m.f[f].v;int n=v.size();
  for(int i=0;i<n;++i){
   int j=(i+1)%n;
   V edge=m.p[v[j]]-m.p[v[i]];
   double approach=dot(offsets[f][i]-offsets[f][j],edge);
   double squared=dot(edge,edge);
   if(squared>0 && approach>=squared*(1.-1e-12)){
    scale=std::min(scale,squared/approach);contact=true;
   }
  }
 }
 for(size_t f=0;f<m.f.size();++f){
  const Loop &v=m.f[f].v;
  for(size_t i=0;i<v.size();++i)corners[f][i]=add(v[i],m.p[v[i]]+offsets[f][i]*scale);
  out.f[f].v=corners[f];
 }
 auto face=[&](Loop v,int src){Loop clean;
  for(int i:v)if(clean.empty()||clean.back()!=i)clean.push_back(i);
  if(clean.size()>1&&clean.front()==clean.back())clean.pop_back();
  if(clean.size()>=3)out.f.push_back({clean,src});
 };
 std::vector<std::map<int,int>> caps(m.p.size());
 std::vector<std::map<int,double>> cornerTips(m.p.size());
 std::vector<int> capSource(m.p.size());
 for(auto &[k,h]:edges){
  if(h.size()!=2||h[0].a!=h[1].b)continue;
  auto a=h[0],b=h[1];int n=corners[a.f].size(),o=corners[b.f].size();
  int l=corners[a.f][a.i],r=corners[a.f][(a.i+1)%n];
  int le=corners[b.f][(b.i+1)%o],re=corners[b.f][b.i];
  if(l==le&&r==re)continue;
  V axis=unit(m.p[a.b]-m.p[a.a]);
  int count=widths[k]>0?segments:1;
  double cosHalf=std::sqrt(std::max(0.,(1+dot(normals[a.f],normals[b.f]))*.5));
  auto arc=[&](int origin,int start,int end,double t){
   V p=out.p[start],q=out.p[end],base=m.p[origin];
   V control=base+axis*dot((p+q)*.5-base,axis);
   double s=1-t,mid=2*s*t*cosHalf;
   return add(origin,(p*(s*s)+q*(t*t)+control*mid)*(1/(s*s+t*t+mid)));
  };
  if(widths[k]>0){
   cornerTips[a.a][l]=cornerTips[a.b][r]=std::abs(normals[a.f].y);
   cornerTips[a.a][le]=cornerTips[a.b][re]=std::abs(normals[b.f].y);
  }
  capSource[a.a]=a.f;capSource[a.b]=a.f;
  int left=l,right=r;
  for(int j=1;j<=count;++j){
   double t=double(j)/count;
   int x=j==count?le:arc(a.a,l,le,t),y=j==count?re:arc(a.b,r,re,t);
   face({right,left,x,y},a.f);
   if(left!=x)caps[a.a][x]=left;
   if(right!=y)caps[a.b][right]=y;
   left=x;right=y;
  }
 }
 for(size_t origin=0;origin<caps.size();++origin)while(!caps[origin].empty()){
  auto &arcs=caps[origin];
  int first=arcs.begin()->first,cur=first;Loop ring;
  do{auto it=arcs.find(cur);if(it==arcs.end())break;
   ring.push_back(cur);cur=it->second;arcs.erase(it);
  }while(cur!=first);
  if(cur!=first||ring.size()<3)continue;
  int src=capSource[origin];
  if(ring.size()==3){
   face(ring,src);
   continue;
  }
  // Three bevel arcs form a spherical triangle. Use the upward-facing
  // face as its pole so that the other two arcs carry continuous rows.
  const auto &tips=cornerTips[origin];
  // A repaired mitre has four sampled sides: two bevel bands, the
  // re-entrant edge and the planar guide. Interpolate their shared grid.
  if(repairLoops && interior[origin] && segments>1 && tips.size()==4 &&
     ring.size()==size_t(4*segments)){
   auto firstTip=std::find_if(ring.begin(),ring.end(),[&](int id){return tips.count(id);});
   if(firstTip!=ring.end())std::rotate(ring.begin(),firstTip,ring.end());
   const int n=segments;
   if(tips.count(ring[n]) && tips.count(ring[2*n]) && tips.count(ring[3*n])){
    std::vector<Loop> grid(n+1,Loop(n+1));
    for(int i=0;i<=n;++i){
     grid[0][i]=ring[i];grid[i][n]=ring[n+i];
     grid[n][i]=ring[3*n-i];grid[i][0]=ring[(4*n-i)%(4*n)];
    }
    for(int j=1;j<n;++j)for(int i=1;i<n;++i){
     double u=double(i)/n,v=double(j)/n;
     V bottom=out.p[grid[0][i]],top=out.p[grid[n][i]];
     V left=out.p[grid[j][0]],right=out.p[grid[j][n]];
     V base=out.p[grid[0][0]]*((1-u)*(1-v))+out.p[grid[0][n]]*(u*(1-v))
           +out.p[grid[n][0]]*((1-u)*v)+out.p[grid[n][n]]*(u*v);
     grid[j][i]=out.p.size();
     out.p.push_back(bottom*(1-v)+top*v+left*(1-u)+right*u-base);
    }
    for(int j=0;j<n;++j)for(int i=0;i<n;++i)
     face({grid[j][i],grid[j][i+1],grid[j+1][i+1],grid[j+1][i]},src);
    continue;
   }
  }
  if(tips.size()==3 && ring.size()==size_t(3*segments)){
   if(repairLoops && interior[origin] && segments>1){
    // Peel three quad strips together. Each corner quad connects matching
    // edge-strip samples; the only extraordinary vertex lies inside the patch.
    auto tip=std::find_if(ring.begin(),ring.end(),[&](int id){return tips.count(id);});
    if(tip!=ring.end())std::rotate(ring.begin(),tip,ring.end());
    if(tips.count(ring[segments]) && tips.count(ring[2*segments])){
     Loop outer=ring;
     V center{};
     for(int id:ring)center=center+out.p[id];
     center=center*(1./ring.size());
     // Extend the curvature of the boundary arcs into the patch.
     V tipMean=(out.p[ring[0]]+out.p[ring[segments]]+out.p[ring[2*segments]])*(1./3);
     center=center+(center-tipMean)*.5;
     int n=segments;
     while(n>1){
      int innerCount=n-2;
      Loop inner;
      if(innerCount==0){
       inner.push_back(out.p.size());out.p.push_back(center);
      }else{
       for(int side=0;side<3;++side)for(int j=0;j<innerCount;++j){
        double t=double(j)*n/innerCount;int k=int(t);
        V a=out.p[outer[side*n+k]],b=out.p[outer[(side*n+k+1)%(3*n)]];
        V sample=a+(b-a)*(t-k);
        inner.push_back(out.p.size());
        out.p.push_back(center+(sample-center)*(double(innerCount)/n));
       }
      }
      for(int side=0;side<3;++side){
       int start=side*n;
       auto inside=[&](int j){return inner[(side*innerCount+j)%inner.size()];};
       face({outer[(start+3*n-1)%(3*n)],outer[start],outer[start+1],inside(0)},src);
       for(int j=0;j<innerCount;++j)
        face({outer[start+j+1],outer[start+j+2],inside(j+1),inside(j)},src);
      }
      outer=std::move(inner);n=innerCount;
     }
     if(n==1)face(outer,src);
     continue;
    }
   }
   auto pole=std::max_element(tips.begin(),tips.end(),
     [](const auto &a,const auto &b){return a.second<b.second;});
   auto start=std::find(ring.begin(),ring.end(),pole->first);
   if(start!=ring.end())std::rotate(ring.begin(),start,ring.end());
   if(start!=ring.end() && tips.count(ring[segments]) && tips.count(ring[2*segments])){
    auto boundary=[&](int i){return ring[i%ring.size()];};
    const V baseLeft=out.p[ring[segments]],baseRight=out.p[ring[2*segments]];
    const double span=length(baseRight-baseLeft);
    if(span>1e-12){
     Loop previous;
     for(int row=1;row<=segments;++row){
      Loop current(segments+1);
      current.front()=boundary(row);current.back()=boundary(3*segments-row);
      V left=out.p[current.front()],right=out.p[current.back()];
      double scale=length(right-left)/span;
      for(int col=1;col<segments;++col){
       int base=ring[segments+col];
       if(row==segments){current[col]=base;continue;}
       double t=double(col)/segments;
       V curvature=out.p[base]-(baseLeft*(1-t)+baseRight*t);
       current[col]=out.p.size();
       out.p.push_back(left*(1-t)+right*t+curvature*scale);
      }
      for(int col=0;col<segments;++col){
       if(row==1)face({ring[0],current[col],current[col+1]},src);
       else face({previous[col],current[col],current[col+1],previous[col+1]},src);
      }
      previous=std::move(current);
     }
     continue;
    }
   }
  }
  face(ring,src);
 }
 if(contact){
  // Only merge vertices whose original edge ends actually met.
  std::vector<int> parent(out.p.size());
  for(size_t i=0;i<parent.size();++i)parent[i]=i;
  auto root=[&](int i){while(parent[i]!=i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
  for(const auto &[k,incident]:edges){
   double tolerance=length(m.p[k.first]-m.p[k.second])*1e-10;
   bool collapsed=false;
   for(const auto &h:incident){
    const auto &loop=corners[h.f];
    if(length(out.p[loop[h.i]]-out.p[loop[(h.i+1)%loop.size()]])<=tolerance)collapsed=true;
   }
   if(!collapsed)continue;
   for(int a:at[k.first])for(int b:at[k.second])
    if(length(out.p[a]-out.p[b])<=tolerance)parent[root(b)]=root(a);
  }
  std::vector<Face> kept;
  for(const Face &f:out.f){
   Loop loop;for(int id:f.v){int i=root(id);if(loop.empty()||loop.back()!=i)loop.push_back(i);}
   if(loop.size()>1 && loop.front()==loop.back())loop.pop_back();
   if(loop.size()>=3 && std::set<int>(loop.begin(),loop.end()).size()==loop.size())
    kept.push_back({std::move(loop),f.source});
  }
  out.f=std::move(kept);
 }
 return out;
}
}
