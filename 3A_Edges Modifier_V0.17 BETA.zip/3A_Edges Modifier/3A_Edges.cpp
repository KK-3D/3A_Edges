#include <lwserver.h>
#include <lwcommand.h>
#include <lwhost.h>
#include <lwmeshmodifier.h>
#include <lwxpanel.h>
#include <sstream>
#include <string>
#include "bevel.hpp"
using namespace bevel;
static GlobalFunc *host;
static LWMeshFuncs *mesh;
static LWXPanelFuncs *pan;
static LWObjectFuncs *objects;
static LWInstUpdate *refresh;
static LWBaseFuncs *bases;
static LWCommandFunc *command;
 struct Entry {int vertex, polygon; std::vector<float> value;};
 struct Map {LWID type; std::string name; int dim; std::vector<Entry> entries;};
struct Source {
 Mesh input;
 std::vector<std::string> surfaces;
 std::vector<Map> maps;
};
struct Settings{
 Source source;
 FaceSet emitted;
 bool radiusEdit=false;
 double radius=.1,angle=30.;int segments=1,repairLoops=0,manual=0,index=0;
 int viewport=1,render=1,mode=LWINIT_PREVIEW;
 LWBaseID base=nullptr;
 std::string map,edges;bool changed=false;
};
static void stackEvent(void *client,LWID event,LWBaseID base){
 auto &v=*(Settings*)client;
 if(base!=v.base || (event!=LWBASEEVENT_DID_ENABLE && event!=LWBASEEVENT_DID_DISABLE))return;
 // Queue a scene evaluation after Layout has finished changing the stack.
 if(command)command("Refresh");
}
static LWInstance create(void*,void *context,LWError*){
 auto *v=new Settings;
 if(context)v->base=((LWContext*)context)->baseID;
 if(v->base && bases)bases->subscribe(v,stackEvent);
 return v;
}
static void destroy(LWInstance x){
 auto *v=(Settings*)x;
 if(v->base && bases)bases->unsubscribe(v);
 delete v;
}
static LWError copy(LWInstance x,LWInstance y){
 auto &dst=*(Settings*)x;auto &src=*(Settings*)y;
 dst.radius=src.radius;dst.angle=src.angle;dst.segments=src.segments;
 dst.viewport=src.viewport;dst.render=src.render;dst.manual=src.manual;dst.repairLoops=src.repairLoops;
 dst.radiusEdit=src.radiusEdit;
 if(src.radiusEdit && !src.source.input.f.empty())dst.source=src.source;
 dst.map=src.map;dst.edges=src.edges;return nullptr;
}
static const char* desc(LWInstance){return "3A_Edges";}
static LWError save(LWInstance x,const LWSaveState*s){
 auto &v=*(Settings*)x;float p[2]={(float)v.radius,(float)v.angle};
 LWSAVE_FP(s,p,2);LWSAVE_I4(s,&v.segments,1);LWSAVE_I4(s,&v.manual,1);
 LWSAVE_STR(s,v.map.c_str());LWSAVE_STR(s,v.edges.c_str());int visibility[]={v.viewport,v.render};LWSAVE_I4(s,visibility,2);LWSAVE_I4(s,&v.repairLoops,1);return nullptr;
}
static LWError load(LWInstance x,const LWLoadState*s){
 auto &v=*(Settings*)x;float p[2];char name[1024]={},edges[8192]={};
 if(LWLOAD_FP(s,p,2)!=2)return "Invalid 3A_Edges settings";
 v.radius=std::max(0.f,p[0]);v.angle=std::clamp(p[1],0.f,180.f);
 LWLOAD_I4(s,&v.segments,1);v.segments=std::clamp(v.segments,1,32);
 LWLOAD_I4(s,&v.manual,1);LWLOAD_STR(s,name,sizeof(name));LWLOAD_STR(s,edges,sizeof(edges));
 int visibility[2]={1,1};if(LWLOAD_I4(s,visibility,2)==2){v.viewport=visibility[0]!=0;v.render=visibility[1]!=0;}
 int repair=0;v.repairLoops=LWLOAD_I4(s,&repair,1)==1 && repair;
 v.map=name;v.edges=edges;return nullptr;
}
static int mapCount(void*){return 1+objects->numVMaps(LWVMAP_WGHT);}
static const char* mapName(void*,int i){return i?objects->vmapName(LWVMAP_WGHT,i-1):"(All weights)";}
enum{Radius=0x8001,Segments,Angle,Weight,Manual,Selection,Viewport,Render,RoundGroup,RenderGroup,TabGroup,RepairLoops};
static void* get(LWInstance x,unsigned id){
 auto &v=*(Settings*)x;
 switch(id){case RepairLoops:return &v.repairLoops;case Viewport:return &v.viewport;case Render:return &v.render;case Radius:return &v.radius;case Segments:return &v.segments;
 case Angle:return &v.angle;case Manual:return &v.manual;case Selection:return (void*)v.edges.c_str();
 case Weight:v.index=0;for(int i=1;i<mapCount(nullptr);++i){auto n=mapName(nullptr,i);if(n&&v.map==n){v.index=i;break;}}return &v.index;}
 return nullptr;
}
static LWXPRefreshCode set(LWInstance x,unsigned id,void *p){
 auto &v=*(Settings*)x;if(!p)return LWXPRC_NONE;
 switch(id){case RepairLoops:v.repairLoops=*(int*)p!=0;break;case Viewport:v.viewport=*(int*)p!=0;break;case Render:v.render=*(int*)p!=0;break;case Radius:v.radiusEdit=true;v.radius=std::max(0.,*(double*)p);break;
 case Segments:v.segments=std::clamp(*(int*)p,1,32);break;
 case Angle:v.angle=std::clamp(*(double*)p,0.,180.);break;
 case Manual:v.manual=*(int*)p;break;case Selection:v.edges=std::string((char*)p).substr(0,8191);break;
 case Weight:{int i=*(int*)p;auto n=i>0&&i<mapCount(nullptr)?mapName(nullptr,i):nullptr;v.map=n?n:"";break;}}
 refresh(LWMESHMODIFIER_HCLASS,x);

 return LWXPRC_DFLT;
}
static size_t collect(void *data,LWMeshID,LWPolID p){((std::vector<LWPolID>*)data)->push_back(p);return 0;}
static unsigned flags(LWInstance){return LWMESHMODIFIERF_NO_MT;}
static unsigned begin(LWInstance x,LWMeshModifierAccess*a){
 auto &v=*(Settings*)x;
 v.changed=false;return 0;
}
static unsigned evaluate(LWInstance x,LWMeshModifierAccess*a){
 auto &v=*(Settings*)x;auto read=a->mesh->read;auto mutate=a->mesh->mutate;
 const auto *scene=(LWSceneInfo*)host(LWSCENEINFO_GLOBAL,GFUSE_TRANSIENT);
 bool finalRender=v.mode==LWINIT_RENDER || (scene && scene->rendermode!=lwrm_None && v.mode!=LWINIT_INTERACTIVE_RENDER);
 if(v.base && bases && (bases->getFlags(v.base)&LWBASEF_DISABLED))return LWMESHMODIFIER_UNCHANGED;
 if(!(finalRender?v.render:v.viewport))return LWMESHMODIFIER_UNCHANGED;



 std::set<Key> chosen;std::string tokens=v.edges;
 for(char &c:tokens)if(c==',')c=' ';
 std::istringstream stream(tokens);int f,e;char sep;
 while(stream>>f>>sep>>e){if(sep!='/')return 0;chosen.insert({f,e});}
 std::vector<LWPolID> polys;mesh->foreach_p(read,collect,&polys);
 Mesh input;std::map<LWPntID,int> lookup;std::vector<LWPntID> ids;std::vector<double> weights;
 std::vector<std::string> surfaces;
 for(auto pol:polys){
  int index=input.f.size();Face face{{},index};
  int n=mesh->num_pol_vertices(read,pol);
  for(int i=0;i<n;++i){
   auto pt=mesh->pol_vertex(read,pol,i);auto [it,inserted]=lookup.emplace(pt,ids.size());
   if(inserted){LWFVector p{};mesh->position(read,pt,p);ids.push_back(pt);input.p.push_back({p[0],p[1],p[2]});
   }
   face.v.push_back(it->second);
  }
  auto tag=mesh->get_pol_tag(read,pol,LWPTAG_SURF);surfaces.emplace_back(tag?tag:"Default");input.f.push_back(face);
 }


 // Snapshot map entries while upstream polygon and point handles are still valid.
 bool previous=(v.radiusEdit && !v.source.input.f.empty()) || containsOutput(input,v.emitted);
 v.radiusEdit=false;
 std::vector<Map> maps;
 if(!previous){
 for(int k=0;objects && k<objects->numVMaps(0);++k){
  LWID type=objects->vmapType(k);auto name=objects->vmapName(0,k);
  if(!name)continue;
  auto id=mesh->vmap_lookup(read,type,name);if(!id)continue;
  int dim=mesh->vmap_dimension(read,id);if(dim<=0)continue;
  Map snapshot{type,name,dim,{}};std::vector<float> value(dim);
  for(size_t i=0;i<ids.size();++i)
   if(mesh->vmap_get(read,id,ids[i],nullptr,value.data()))
    snapshot.entries.push_back({(int)i,-1,value});
  for(size_t f=0;f<input.f.size();++f)for(int i:input.f[f].v)
   if(mesh->vmap_get(read,id,ids[i],polys[f],value.data()))
    snapshot.entries.push_back({i,(int)f,value});
  maps.push_back(std::move(snapshot));
 }
 v.source={std::move(input),std::move(surfaces),std::move(maps)};
 }
 auto &source=v.source;
 weights.assign(source.input.p.size(),v.map.empty()?1.:0.);
 for(const auto &layer:source.maps)if(layer.type==LWVMAP_WGHT && layer.name==v.map)
  for(const auto &entry:layer.entries)if(entry.polygon<0)
   weights[entry.vertex]=std::clamp(entry.value[0],0.f,1.f);
 Mesh out=run(source.input,v.radius,v.segments,weights,v.manual,chosen,v.angle*.0174532925199433,v.repairLoops);
 if(!previous && out.p.size()==source.input.p.size())return 0;
 // Rebuild the derived layer from the evaluated snapshot. No input ID is reused.
 mesh->clear(mutate);mesh->use_only_frozen(mutate,2);
 std::vector<LWPntID> points(out.p.size());std::vector<LWPolID> faces(out.f.size());
 for(size_t i=0;i<out.f.size();++i){
  const auto &face=out.f[i];std::vector<LWPntID> verts;
  for(int index:face.v){
   if(!points[index]){auto p=out.p[index];LWFVector q={(float)p.x,(float)p.y,(float)p.z};
    points[index]=mesh->new_vertex(mutate,q);}
   verts.push_back(points[index]);
  }
  faces[i]=mesh->new_polygon(mutate,LWPOLTYPE_FACE,source.surfaces[face.source].c_str(),verts.size(),verts.data());
 }
 for(auto &map:source.maps)for(auto &entry:map.entries){
  if(!points[entry.vertex])continue;
  LWPolID poly=nullptr;
  if(entry.polygon>=0){
   auto match=std::find_if(out.f.begin(),out.f.end(),[&](const Face &f){
    return f.source==entry.polygon && std::find(f.v.begin(),f.v.end(),entry.vertex)!=f.v.end();
   });
   if(match==out.f.end())continue;
   auto &loop=match->v;
   if(std::find(loop.begin(),loop.end(),entry.vertex)==loop.end())continue;
   poly=faces[match-out.f.begin()];
  }
  mesh->vmap_set(mutate,map.type,map.name.c_str(),map.dim,points[entry.vertex],poly,entry.value.data());
 }
 v.emitted=faceSet(out);
 v.changed=true;return LWMESHMODIFIER_GEOCHANGED;
}
static void end(LWInstance x,LWMeshModifierAccess*a){if(((Settings*)x)->changed)mesh->process_geometry(a->mesh->mutate);}
static LWError init(LWInstance x,int mode){((Settings*)x)->mode=mode;return nullptr;}
static void cleanup(LWInstance x){((Settings*)x)->mode=LWINIT_PREVIEW;}
static LWError newTime(LWInstance,LWFrame,LWTime){return nullptr;}
static int activate(int version,GlobalFunc*g,LWMeshModifierHandler*h,void*){
 if(version!=LWMESHMODIFIER_VERSION)return AFUNC_BADVERSION;
 host=g;bases=(LWBaseFuncs*)g(LWBASEFUNCS_GLOBAL,GFUSE_TRANSIENT);
 command=(LWCommandFunc*)g(LWCOMMANDFUNC_GLOBAL,GFUSE_TRANSIENT);
 objects=(LWObjectFuncs*)g(LWOBJECTFUNCS_GLOBAL,GFUSE_TRANSIENT);
 mesh=(LWMeshFuncs*)g(LWMESHFUNCS_GLOBAL,GFUSE_TRANSIENT);if(!mesh)return AFUNC_BADGLOBAL;
 h->inst->create=create;h->inst->destroy=destroy;h->inst->copy=copy;h->inst->save=save;h->inst->load=load;h->inst->descln=desc;
 h->rend->init=init;h->rend->cleanup=cleanup;h->rend->newTime=newTime;h->flags=flags;h->begin=begin;h->evaluate=evaluate;h->end=end;return AFUNC_OK;
}
static int interface(int version,GlobalFunc*g,LWInterface*h,void*){
 if(version!=LWINTERFACE_VERSION)return AFUNC_BADVERSION;
 pan=(LWXPanelFuncs*)g(LWXPANELFUNCS_GLOBAL,GFUSE_TRANSIENT);objects=(LWObjectFuncs*)g(LWOBJECTFUNCS_GLOBAL,GFUSE_TRANSIENT);
 refresh=(LWInstUpdate*)g(LWINSTUPDATE_GLOBAL,GFUSE_TRANSIENT);if(!pan||!objects||!refresh)return AFUNC_BADGLOBAL;
 static LWXPanelControl controls[]={{Radius,"Radius","distance"},{Segments,"Segments","integer"},{RepairLoops,"Repair Curve Loops","iBoolean"},{Angle,"Minimum Angle (degrees)","float"},{Weight,"Weight Map","iPopChoice"},{Manual,"Use Edge Selection","iBoolean"},{Selection,"Edges (face/edge)","string"},{Viewport,"Show in Viewport","iBoolean"},{Render,"Show in Render","iBoolean"},{0}};
 static LWXPanelDataDesc data[]={{Radius,"Radius","distance"},{Segments,"Segments","integer"},{RepairLoops,"Repair Curve Loops","integer"},{Angle,"Minimum Angle","float"},{Weight,"Weight Map","integer"},{Manual,"Use Edge Selection","integer"},{Selection,"Edges","string"},{Viewport,"Show in Viewport","integer"},{Render,"Show in Render","integer"},{0}};
 static LWXPanelHint hints[]={XpTRACK(Radius,1),XpTRACK(Segments,1),XpTRACK(Angle,1),XpPOPFUNCS(Weight,mapCount,mapName),
  XpGROUP_(RoundGroup),XpH(Radius),XpH(Segments),XpH(RepairLoops),XpH(Angle),XpH(Weight),XpH(Manual),XpH(Selection),XpH(0),
  XpGROUP_(RenderGroup),XpH(Viewport),XpH(Render),XpH(0),
  XpLABEL(RoundGroup,"Round"),XpLABEL(RenderGroup,"Render"),
  XpTABS_(TabGroup),XpH(RoundGroup),XpH(RenderGroup),XpH(0),XpEND};
 h->panel=pan->create(LWXP_VIEW,controls);if(!h->panel)return AFUNC_BADGLOBAL;
 pan->describe(h->panel,data,get,set);pan->hint(h->panel,0,hints);pan->viewInst(h->panel,h->inst);h->options=nullptr;h->command=nullptr;return AFUNC_OK;
}
extern "C" {ServerTagInfo tags[]={{"3A_Edges",SRVTAG_USERNAME},{nullptr,0}};
ServerRecord ServerDesc[]={{LWMESHMODIFIER_HCLASS,"3A_Edges",(ActivateFunc*)activate,tags},{LWMESHMODIFIER_ICLASS,"3A_Edges",(ActivateFunc*)interface,tags},{0}};}
